package com.example.depositsapplication;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

class MyViewHolder extends RecyclerView.ViewHolder {
    View myview;

    public MyViewHolder(@NonNull View itemView) {
        super(itemView);
        myview = itemView;
    }

    public void setTitle(String title){
        TextView mTitle=myview.findViewById(R.id.title);
        mTitle.setText(title);
    }

    public void setNote(String note){
        TextView mNote=myview.findViewById(R.id.note);
        mNote.setText(note);
    }

    public void setDate(String date){
        TextView mDate=myview.findViewById(R.id.date);
        mDate.setText(date);
    }
}
